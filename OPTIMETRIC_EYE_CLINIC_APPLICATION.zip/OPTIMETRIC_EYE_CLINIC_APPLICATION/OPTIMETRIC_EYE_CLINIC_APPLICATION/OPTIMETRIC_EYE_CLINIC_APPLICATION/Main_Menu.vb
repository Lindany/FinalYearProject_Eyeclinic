﻿Public Class MainMenu
    Public Sub FormSetUp(ByVal ChildForm As Form)
        Try
            If Not (ChildForm.Equals(Me.ActiveMdiChild)) Then
                Me.ActiveMdiChild.Close()
            End If
        Catch ex As Exception
        End Try
        With ChildForm
            .MdiParent = Me
            .WindowState = FormWindowState.Maximized
            .Show()
        End With
    End Sub


    Private Sub ToolStripMenuItem2_Click(sender As Object, e As EventArgs) Handles ToolStripMenuItem2.Click
        Login.Show()
    End Sub

    Private Sub ToolStripMenuItem8_Click(sender As Object, e As EventArgs) Handles ToolStripMenuItem8.Click
        ChangePassord.Show()
    End Sub


    Private Sub Timer1_Tick(sender As System.Object, e As System.EventArgs) Handles Timer1.Tick
        Label2.Text = Format(Now, "HH:mm:ss")
    End Sub

    Private Sub ToolStripMenuItem11_Click(sender As System.Object, e As System.EventArgs) Handles ToolStripMenuItem11.Click
        FormSetUp(NewAdministractor)
    End Sub

    Private Sub ToolStripMenuItem13_Click(sender As System.Object, e As System.EventArgs) Handles ToolStripMenuItem13.Click
        FormSetUp(NewPatient)

    End Sub

    Private Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        ToolStripMenuItem3.Enabled = False
        ToolStripMenuItem4.Enabled = False
        ToolStripMenuItem6.Enabled = False
        ToolStripMenuItem9.Enabled = False
        ManageToolStripMenuItem.Enabled = False
        SearchToolStripMenuItem.Enabled = False
        Patient.Enabled = False
        TestResultsToolStripMenuItem.Enabled = False
        PaymentToolStripMenuItem.Enabled = False

    End Sub

    Private Sub ToolStripMenuItem4_Click(sender As System.Object, e As System.EventArgs) Handles ToolStripMenuItem4.Click
        FormSetUp(MakeAnAppointment)

    End Sub

    Private Sub ToolStripMenuItem6_Click(sender As System.Object, e As System.EventArgs) Handles ToolStripMenuItem6.Click
        FormSetUp(AddPatient)
    End Sub

    Private Sub AllocateTraineeStudedentToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles AllocateTraineeStudedentToolStripMenuItem.Click

    End Sub

    Private Sub TraineeStudentToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles TraineeStudentToolStripMenuItem.Click
        Search.Show()

    End Sub
End Class
