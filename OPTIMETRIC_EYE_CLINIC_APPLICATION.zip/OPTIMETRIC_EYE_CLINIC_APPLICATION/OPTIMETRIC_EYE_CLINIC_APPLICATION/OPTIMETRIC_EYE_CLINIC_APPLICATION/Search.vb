﻿Public Class Search




    Private Sub Search_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'DataSet1.Staff' table. You can move, or remove it, as needed.
        Me.StaffTableAdapter.Fill(Me.DataSet1.Staff)
        'TODO: This line of code loads data into the 'DataSet1.Staff' table. You can move, or remove it, as needed.
        Me.StaffTableAdapter.Fill(Me.DataSet1.Staff)

    End Sub

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        StaffTableAdapter.FillBy(DataSet1.Staff, name.Text, surname.Text)

    End Sub

End Class