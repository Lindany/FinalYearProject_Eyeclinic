﻿Public Class NewAdministractor

    Private Sub NewAdministractor_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'DataSet1.Staff' table. You can move, or remove it, as needed.
        ' Me.StaffTableAdapter.Fill(Me.DataSet1.Staff)
        'TODO: This line of code loads data into the 'DataSet1.Administrator' table. You can move, or remove it, as needed.
        ' Me.AdministratorTableAdapter.Fill(Me.DataSet1.Administrator)
        TextBox12.Text = StaffBindingSource.Count + 1
        TextBox13.Text = AdministratorBindingSource.Count + 1
    End Sub

    Private Sub ToolStripButton3_Click(sender As System.Object, e As System.EventArgs) Handles ToolStripButton3.Click
        Dim gen As String 'New var to hold data from the radio button
        If RadioButton1.Checked Then
            gen = "F"
        Else
            gen = "M"
        End If
        'Dim adminNo = Convert.ToInt32(Math.Round(NumericUpDown1.Value, 0))
        StaffBindingSource.EndEdit()
        StaffTableAdapter.InsertQuery(TextBox8.Text, TextBox1.Text, TextBox2.Text, TextBox3.Text, gen, DateTimePicker1.Text, TextBox7.Text, TextBox4.Text, TextBox5.Text, TextBox6.Text, TextBox9.Text, TextBox10.Text, TextBox11.Text)
        AdministratorTableAdapter.InsertQuery(Convert.ToInt32(TextBox12.Text)) 'Inserting ID
        MessageBox.Show("Administrator " + TextBox3.Text + " Inserted successfly")
    End Sub

    Private Sub ToolStripButton1_Click(sender As System.Object, e As System.EventArgs) Handles ToolStripButton1.Click
        StaffBindingSource.AddNew() 'Updating or modifying existing data
        StaffBindingSource.EndEdit()
        StaffTableAdapter.Update(DataSet1.Staff)
        MessageBox.Show("Administrator " + TextBox3.Text + " Updated successfly")
    End Sub

    Private Sub ToolStripButton2_Click(sender As System.Object, e As System.EventArgs) Handles ToolStripButton2.Click
        TextBox1.Text = 0
        TextBox2.Clear()
        TextBox3.Clear()
        TextBox4.Clear()
        TextBox5.Clear()
        TextBox6.Clear()
        TextBox7.Clear()
        TextBox8.Clear()
        TextBox9.Clear()
        TextBox10.Clear()
        TextBox11.Clear()
        TextBox12.Clear()
        TextBox13.Clear()
        

    End Sub

    Private Sub ToolStrip1_ItemClicked(sender As System.Object, e As System.Windows.Forms.ToolStripItemClickedEventArgs) Handles ToolStrip1.ItemClicked
        Me.Hide()
        Me.Close
        MainMenu.Show()
    End Sub
End Class