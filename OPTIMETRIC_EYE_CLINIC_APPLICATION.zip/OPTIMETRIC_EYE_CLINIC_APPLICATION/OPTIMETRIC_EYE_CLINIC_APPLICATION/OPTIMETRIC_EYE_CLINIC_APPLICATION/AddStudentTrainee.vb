﻿Public Class NewPatient

    Private Sub NewPatient_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'DataSet1.Trainee_Student' table. You can move, or remove it, as needed.
        Me.Trainee_StudentTableAdapter.Fill(Me.DataSet1.Trainee_Student)
        'TODO: This line of code loads data into the 'DataSet1.Staff' table. You can move, or remove it, as needed.
        Me.StaffTableAdapter.Fill(Me.DataSet1.Staff)
        TextBox8.Text = FKTraineeStudentStaffBindingSource.Count + 1

    End Sub

    Private Sub ToolStripButton3_Click(sender As System.Object, e As System.EventArgs) Handles ToolStripButton3.Click
        Dim gen As String 'New var to hold data from the radio button
        If RadioButton1.Checked Then
            gen = "F"
        Else
            gen = "M"
        End If
        Dim stuNo = TextBox13.Text
        StaffTableAdapter.InsertQuery(TextBox1.Text, TextBox12.Text, TextBox2.Text, TextBox3.Text, gen, DateTimePicker1.Text, TextBox7.Text, TextBox4.Text, TextBox5.Text, TextBox6.Text, TextBox9.Text, TextBox10.Text, TextBox11.Text)
        FKTraineeStudentStaffBindingSource.EndEdit()
        Trainee_StudentTableAdapter.Fill(DataSet1.Trainee_Student)
        Trainee_StudentTableAdapter.InsertQuery(stuNo) 'Inserting ID
        MessageBox.Show("Administrator " + TextBox3.Text + " Inserted successfly")
    End Sub

    Private Sub ToolStripButton2_Click(sender As System.Object, e As System.EventArgs) Handles ToolStripButton2.Click
        TextBox1.Text = 0
        TextBox2.Clear()
        TextBox3.Clear()
        TextBox4.Clear()
        TextBox5.Clear()
        TextBox6.Clear()
        TextBox7.Clear()
        TextBox9.Clear()
        TextBox10.Clear()
        TextBox11.Clear()
        TextBox13.Clear()
    End Sub

    Private Sub ToolStrip1_ItemClicked(sender As System.Object, e As System.Windows.Forms.ToolStripItemClickedEventArgs) Handles ToolStrip1.ItemClicked
        Me.Close()
        MainMenu.Show()

    End Sub

    Private Sub ToolStripButton1_Click(sender As System.Object, e As System.EventArgs) Handles ToolStripButton1.Click
        FKTraineeStudentStaffBindingSource.AddNew()
        FKTraineeStudentStaffBindingSource.EndEdit()
        StaffBindingSource.EndEdit()
        StaffTableAdapter.Fill(DataSet1.Staff)
        Trainee_StudentTableAdapter.Fill(DataSet1.Trainee_Student)
        MessageBox.Show("Record Updated")
    End Sub
End Class