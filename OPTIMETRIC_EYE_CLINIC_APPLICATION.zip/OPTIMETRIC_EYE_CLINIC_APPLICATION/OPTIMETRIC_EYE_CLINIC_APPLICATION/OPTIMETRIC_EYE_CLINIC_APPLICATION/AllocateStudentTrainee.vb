﻿Public Class AllocateStudentTrainee

End Class