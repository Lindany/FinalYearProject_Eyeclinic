﻿Partial Class DataSet1
End Class

Namespace DataSet1TableAdapters
    
    Partial Public Class StaffTableAdapter
    End Class
End Namespace
