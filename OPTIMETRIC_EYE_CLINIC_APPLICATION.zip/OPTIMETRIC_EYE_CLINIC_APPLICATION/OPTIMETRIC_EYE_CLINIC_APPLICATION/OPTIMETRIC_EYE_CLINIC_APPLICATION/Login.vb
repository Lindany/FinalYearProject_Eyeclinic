﻿
Public Class Login

    Private Sub Login_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'DataSet1.Administrator' table. You can move, or remove it, as needed.
        Me.AdministratorTableAdapter.Fill(Me.DataSet1.Administrator)
        'TODO: This line of code loads data into the 'DataSet1.Trainee_Student' table. You can move, or remove it, as needed.
        Me.Trainee_StudentTableAdapter.Fill(Me.DataSet1.Trainee_Student)
        'TODO: This line of code loads data into the 'DataSet1.Staff' table. You can move, or remove it, as needed.
        Me.StaffTableAdapter.Fill(Me.DataSet1.Staff)

    End Sub

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        ' Dim gen As String 'New var to hold data from the radio button
        If RadioButton1.Checked Then
            AdministratorTableAdapter.FillBy(DataSet1.Administrator, TextBox1.Text, TextBox2.Text)
            If DataSet1.Administrator.Rows.Count > 0 Then
                MessageBox.Show("Welcome: You will now be redirected to the system")
                Me.Close()

                With MainMenu
                    .Show()
                    .ToolStripMenuItem13.Enabled = True
                    .ToolStripMenuItem3.Enabled = True
                    .ToolStripMenuItem4.Enabled = True
                    .ToolStripMenuItem6.Enabled = True
                    .ToolStripMenuItem9.Enabled = True
                    .ManageToolStripMenuItem.Enabled = True
                    .SearchToolStripMenuItem.Enabled = True
                    .PaymentToolStripMenuItem.Enabled = True
                    .Patient.Enabled = True
                End With
            Else
                MessageBox.Show("Invalid User Details")
                TextBox1.Clear()
                TextBox2.Clear()
                Me.Close()
            End If
        Else
            Trainee_StudentTableAdapter.FillBy(DataSet1.Trainee_Student, TextBox1.Text, TextBox2.Text)
            If DataSet1.Trainee_Student.Rows.Count > 0 Then
                MessageBox.Show("Welcome: You will now be redirected to the system")

                With MainMenu
                    .Show()
                    .SearchToolStripMenuItem.Enabled = True
                    .TestResultsToolStripMenuItem.Enabled = True
                End With
                Me.Close()
            Else
                MessageBox.Show("Invalid User Details")
                TextBox1.Clear()
                TextBox2.Clear()
                Me.Close()
            End If
        End If
    End Sub
End Class