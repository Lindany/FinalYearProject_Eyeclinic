﻿Public Class AddPatient

    Private Sub AddPatient_Load(sender As System.Object, e As System.EventArgs)
        'TODO: This line of code loads data into the 'DataSet1.Patient' table. You can move, or remove it, as needed.
        Me.PatientTableAdapter.Fill(Me.DataSet1.Patient)

    End Sub

    Private Sub ToolStripButton3_Click(sender As System.Object, e As System.EventArgs)
        Dim gen As String 'New var to hold data from the radio button
        If RadioButton1.Checked Then
            gen = "F"
        Else
            gen = "M"
        End If
        Dim adminNo = Convert.ToInt32(Math.Round(NumericUpDown1.Value, 0))
        PatientTableAdapter.Insert(TextBox1.Text, TextBox2.Text, TextBox3.Text, gen, DateTimePicker1.Text, TextBox7.Text, TextBox4.Text, TextBox5.Text, TextBox6.Text, TextBox9.Text, TextBox10.Text, TextBox11.Text)
        MessageBox.Show("Patuent " + TextBox3.Text + " Inserted successfly")
    End Sub

    Private Sub ToolStrip1_ItemClicked(sender As System.Object, e As System.Windows.Forms.ToolStripItemClickedEventArgs)

    End Sub

    Private Sub ToolStripButton2_Click(sender As System.Object, e As System.EventArgs)
        TextBox1.Text = 0
        TextBox2.Clear()
        TextBox3.Clear()
        TextBox4.Clear()
        TextBox5.Clear()
        TextBox6.Clear()
        TextBox7.Clear()
        NumericUpDown1.Value = 0
        NumericUpDown2.Value = 0
        TextBox9.Clear()
        TextBox10.Clear()
        TextBox11.Clear()
    End Sub

    Private Sub AddPatient_Load_1(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'DataSet1.Patient' table. You can move, or remove it, as needed.
        Me.PatientTableAdapter.Fill(Me.DataSet1.Patient)

    End Sub

    Private Sub ToolStripButton3_Click_1(sender As System.Object, e As System.EventArgs) Handles ToolStripButton3.Click
        Dim gen As String 'New var to hold data from the radio button
        If RadioButton1.Checked Then
            gen = "F"
        Else
            gen = "M"
        End If
        Dim adminNo = Convert.ToInt32(Math.Round(NumericUpDown2.Value, 0))
        Dim stuNo = Convert.ToInt32(Math.Round(NumericUpDown1.Value, 0))
        PatientTableAdapter.Insert(TextBox2.Text, TextBox3.Text, TextBox1.Text, stuNo, adminNo, Convert.ToInt32(TextBox5.Text), TextBox4.Text, TextBox7.Text, gen, TextBox9.Text, TextBox10.Text, TextBox11.Text)
        MessageBox.Show("Patuent " + TextBox3.Text + " Inserted successfly")
    End Sub
End Class