﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace groupweb
{
    public class Global
    {
        public static string LoggedInUserName { set; get; }
    }
}