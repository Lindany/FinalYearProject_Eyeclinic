﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web.Security;


namespace groupweb.Account
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            RegisterHyperLink.NavigateUrl = "Register.aspx?ReturnUrl=" + HttpUtility.UrlEncode(Request.QueryString["ReturnUrl"]);
        }

        protected void LoginButton_Click(object sender, EventArgs e)
        {
            string[] userRole = Roles.GetRolesForUser(LoginUser.UserName);
            
            if (Roles.IsUserInRole(LoginUser.UserName, "Admin"))
            {
                Global.LoggedInUserName = LoginUser.UserName;
                Response.Redirect("~/Admin/AdminHome.aspx");
                Global.LoggedInUserName = "Njabulo.Jay";
            }
           
        }
    }
}