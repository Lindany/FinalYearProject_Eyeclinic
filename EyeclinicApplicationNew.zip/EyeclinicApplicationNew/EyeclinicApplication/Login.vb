﻿Public Class Login


    Private Sub Login_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'EyeclinicDataset.Administrator' table. You can move, or remove it, as needed.
        Me.AdministratorTableAdapter.Fill(Me.EyeclinicDataset.Administrator)
        'TODO: This line of code loads data into the 'EyeclinicDataset.Staff' table. You can move, or remove it, as needed.
        Me.StaffTableAdapter.Fill(Me.EyeclinicDataset.Staff)
        'TODO: This line of code loads data into the 'EyeclinicDataset.TraineeStudent' table. You can move, or remove it, as needed.
        Me.TraineeStudentTableAdapter.Fill(Me.EyeclinicDataset.TraineeStudent)

    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        MainMenu.Show()
        Me.Close()
    End Sub

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        ' Dim gen As String 'New var to hold data from the radio button
        MainMenu.global_username = TextBox1.Text
       
        If RadioButton1.Checked Then
            MainMenu.global_staffType = "Administrator"
            AdministratorTableAdapter.FillBy(EyeclinicDataset.Administrator, TextBox1.Text, TextBox2.Text)
            If EyeclinicDataset.Administrator.Rows.Count > 0 Then
                MessageBox.Show("Welcome: You will now be redirected to the system")
                MainMenu.global_staffid = StaffTableAdapter.returnStaffID(TextBox1.Text, TextBox2.Text)
                With MainMenu
                    .Show()
                End With
                Me.Close()
            Else

                MessageBox.Show("Invalid User Details")
                TextBox1.Clear()
                TextBox2.Clear()
            End If
        Else
            MainMenu.global_staffType = "Trainee Student"
            TraineeStudentTableAdapter.FillBy(EyeclinicDataset.TraineeStudent, TextBox1.Text, TextBox2.Text)
            If EyeclinicDataset.TraineeStudent.Rows.Count > 0 Then
                MessageBox.Show("Welcome: You will now be redirected to the system")

                With MainMenu
                    .Show()

                End With
                Me.Close()
            Else
                MessageBox.Show("Invalid User Details")
                TextBox1.Clear()
                TextBox2.Clear()
            End If
        End If
    End Sub
End Class