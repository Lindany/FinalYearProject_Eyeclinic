﻿Public Class AddNewPatient

    Private Sub AddNewPatient_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'EyeclinicDataset.Patient' table. You can move, or remove it, as needed.
        Me.PatientTableAdapter.Fill(Me.EyeclinicDataset.Patient)

    End Sub



    Private Sub ToolStripButton3_Click(sender As System.Object, e As System.EventArgs) Handles ToolStripButton3.Click
        Dim gen As String 'New var to hold data from the radio button
        If RadioButton1.Checked Then
            gen = "F"
        Else
            gen = "M"
        End If

        Dim conf_var As Integer = PatientTableAdapter.InsertPatient(boxfname.Text, boxlname.Text, boxID.Text, boxStuNo.Text, boxStaffID.Text, boxtel.Text, boxphy.Text, boxPostal.Text, gen, boxnokname.Text, boxnokTel.Text, boxnokRel.Text, Convert.ToDecimal(0))
        PatientBindingSource.EndEdit()
        PatientTableAdapter.Update(EyeclinicDataset.Patient)
        Me.PatientTableAdapter.Fill(Me.EyeclinicDataset.Patient)
        MessageBox.Show("Patient " + boxlname.Text + " Inserted successfly", "Insertion Confirmation: " & conf_var, MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

End Class
